# Power-Consumption-Prediction
project - power consumption prediction

Based on the historical electricity consumption data of more than 1000 enterprises in a high-tech Zone, design algorithms to predict the daily total electricity consumption of the Zone in next month (next 30 days).
